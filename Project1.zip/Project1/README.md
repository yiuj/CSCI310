# Project 1

To build:
    $ ant compile

To create .jar files:
    $ ant dist

To create documentation:
    $ ant doc

To run JUnit tests:
    $ ant test

To run:
    $ cd bin/
    $ java SearchMap <inputfile> <outputfile>

To clean project:
    $ ant clean